//package com.example.nimble.mainmenu
//
//import android.app.Activity
//import android.view.View
//import android.view.ViewGroup
//import android.widget.ArrayAdapter
//
//class CategoriesAdapter (private val context: Activity, private val title: Array<String>, private val distances: Array<Double>, /**, private val imgid: Array<Int>**/)
//: ArrayAdapter<String>(context, title) {
//    override fun getView(position: Int, view: View?, parent: ViewGroup): View {
//
//
//    }
//}