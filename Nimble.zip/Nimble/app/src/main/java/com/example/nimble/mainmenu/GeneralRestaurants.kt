package com.example.nimble.mainmenu

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.nimble.R

class GeneralRestaurants : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_general_restaurants2)
    }
}